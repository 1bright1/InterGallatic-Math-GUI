#ifndef USER_H
#define USER_H

#include <string>
using namespace std;


class user
{
public:
    user();
    int grade;
};

#endif // USER_H
