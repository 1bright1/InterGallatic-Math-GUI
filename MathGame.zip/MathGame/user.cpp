#include "user.h"

user::user()
{
}
